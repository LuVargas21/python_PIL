from django.contrib import admin
from apps.transaction.models import Transaction

# Register your models here.
admin.site.register(Transaction)